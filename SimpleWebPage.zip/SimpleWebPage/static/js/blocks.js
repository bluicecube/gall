function addTapBlock(parent) {
  const tapBlock = {
      type: 'tap',
      region: null,
      name: 'Tap Block'
  };
  parent.blocks.push(tapBlock);

  const blockDiv = document.createElement('div');
  blockDiv.className = 'block tap-block';
  blockDiv.draggable = true;
  blockDiv.innerHTML = `
      <div class="d-flex justify-content-between align-items-center mb-2">
          <h6 class="block-name" contenteditable="true">${tapBlock.name}</h6>
          <button class="btn-close btn-close-white delete-block" aria-label="Delete"></button>
      </div>
      <div class="region-info text-muted">Click to select region</div>
  `;

  setupDragAndDrop(blockDiv);

  blockDiv.querySelector('.btn-close').addEventListener('click', () => {
      const index = parent.blocks.indexOf(tapBlock);
      if (index > -1) {
          parent.blocks.splice(index, 1);
          blockDiv.remove();
          logLiveConsole('Tap block removed', 'info');
      }
  });

  // Click handler for the whole block to enable drawing mode
  blockDiv.addEventListener('click', (e) => {
      if (!e.target.closest('.delete-dot')) {
          setBlockFocus(tapBlock, blockDiv);
          enableDrawingMode(tapBlock, blockDiv);
      }
  });

  // Auto-focus new tap block
  setTimeout(() => {
      setBlockFocus(tapBlock, blockDiv);
      enableDrawingMode(tapBlock, blockDiv);
  }, 0);

  return blockDiv;
}

function addLoopBlock(parent) {
  const loopBlock = {
      type: 'loop',
      iterations: 1,
      blocks: [],
      name: 'Loop Block'
  };
  parent.blocks.push(loopBlock);

  const blockDiv = document.createElement('div');
  blockDiv.className = 'block loop-block';
  blockDiv.innerHTML = `
      <div class="delete-dot"></div>
      <div class="d-flex justify-content-between align-items-center mb-2">
          <h6 class="block-name" contenteditable="true">${loopBlock.name}</h6>
      </div>
      <div class="input-group mb-2">
          <span class="input-group-text">Iterations</span>
          <input type="number" class="form-control iterations-input" value="1" min="1">
      </div>
      <div class="nested-blocks"></div>
      <div class="d-flex gap-2 mt-2">
          <button class="btn btn-sm btn-outline-primary add-tap-btn">Add Tap</button>
          <button class="btn btn-sm btn-outline-info add-print-btn">Add Print</button>
      </div>
  `;

  blockDiv.querySelector('.delete-dot').addEventListener('click', () => {
      const index = parent.blocks.indexOf(loopBlock);
      if (index > -1) {
          parent.blocks.splice(index, 1);
          blockDiv.remove();
          logLiveConsole('Loop block removed', 'info');
      }
  });

  blockDiv.querySelector('.iterations-input').addEventListener('change', (e) => {
      loopBlock.iterations = parseInt(e.target.value) || 1;
  });

  blockDiv.querySelector('.add-tap-btn').addEventListener('click', () => {
      const tapDiv = addTapBlock(loopBlock);
      blockDiv.querySelector('.nested-blocks').appendChild(tapDiv);
  });

  blockDiv.querySelector('.add-print-btn').addEventListener('click', () => {
      const printDiv = addPrintBlock(loopBlock);
      blockDiv.querySelector('.nested-blocks').appendChild(printDiv);
  });

  return blockDiv;
}

function addPrintBlock(parent) {
  const printBlock = {
      type: 'print',
      message: '',
      name: 'Print Block'
  };
  parent.blocks.push(printBlock);

  const blockDiv = document.createElement('div');
  blockDiv.className = 'block print-block';
  blockDiv.draggable = true;
  blockDiv.innerHTML = `
      <div class="delete-dot"></div>
      <div class="d-flex justify-content-between align-items-center mb-2">
          <h6 class="block-name" contenteditable="true">${printBlock.name}</h6>
      </div>
      <div class="input-group">
          <span class="input-group-text">Message</span>
          <input type="text" class="form-control message-input" value="${printBlock.message}" placeholder="Enter message">
      </div>
  `;

  setupDragAndDrop(blockDiv);

  const messageInput = blockDiv.querySelector('.message-input');
  messageInput.addEventListener('input', (e) => {
      printBlock.message = e.target.value;
      console.log('Print block message updated:', printBlock.message); // Debug log
  });

  blockDiv.querySelector('.delete-dot').addEventListener('click', () => {
      const index = parent.blocks.indexOf(printBlock);
      if (index > -1) {
          parent.blocks.splice(index, 1);
          blockDiv.remove();
          logLiveConsole('Print block removed', 'info');
      }
  });

  blockDiv.addEventListener('click', (e) => {
      if (!e.target.closest('.delete-dot')) {
          setBlockFocus(printBlock, blockDiv);
      }
  });

  return blockDiv;
}

function setupDragAndDrop(element) {
  element.addEventListener('dragstart', (e) => {
      e.target.classList.add('dragging');
  });

  element.addEventListener('dragend', (e) => {
      e.target.classList.remove('dragging');
  });

  element.addEventListener('dragover', (e) => {
      e.preventDefault();
      const draggable = document.querySelector('.dragging');
      const container = e.target.closest('.blocks-container');

      if (container && draggable) {
          const afterElement = getDragAfterElement(container, e.clientY);
          if (afterElement) {
              container.insertBefore(draggable, afterElement);
          } else {
              container.appendChild(draggable);
          }
      }
  });
}

function getDragAfterElement(container, y) {
  const draggableElements = [...container.querySelectorAll('.block:not(.dragging)')];

  return draggableElements.reduce((closest, child) => {
      const box = child.getBoundingClientRect();
      const offset = y - box.top - box.height / 2;

      if (offset < 0 && offset > closest.offset) {
          return { offset: offset, element: child };
      } else {
          return closest;
      }
  }, { offset: Number.NEGATIVE_INFINITY }).element;
}

function enableDrawingMode(tapBlock, tapDiv) {
    // Remove active state from other blocks
    document.querySelectorAll('.active-block').forEach(block => {
        if (block !== tapDiv) {
            block.classList.remove('active-block');
        }
    });

    tapDiv.classList.add('active-block');
    const simulator = document.getElementById('simulator');
    const selectionBox = document.getElementById('selectionBox');

    let isSelecting = false;
    let startPos = { x: 0, y: 0 };

    // Remove existing listeners to prevent duplicates
    simulator.removeEventListener('mousedown', startSelection);
    simulator.removeEventListener('mousemove', updateSelection);
    simulator.removeEventListener('mouseup', endSelection);

    simulator.addEventListener('mousedown', startSelection);
    simulator.addEventListener('mousemove', updateSelection);
    simulator.removeEventListener('mouseup', endSelection);


    function startSelection(e) {
        if (!currentTapBlock || e.target.closest('.block')) return;

        const rect = simulator.getBoundingClientRect();
        startPos = {
            x: e.clientX - rect.left,
            y: e.clientY - rect.top
        };

        selectionBox.classList.remove('d-none');
        selectionBox.style.left = `${startPos.x}px`;
        selectionBox.style.top = `${startPos.y}px`;
        selectionBox.style.width = '0px';
        selectionBox.style.height = '0px';

        isSelecting = true;
    }

    function updateSelection(e) {
        if (!isSelecting) return;

        const rect = simulator.getBoundingClientRect();
        const currentPos = {
            x: e.clientX - rect.left,
            y: e.clientY - rect.top
        };

        const width = currentPos.x - startPos.x;
        const height = currentPos.y - startPos.y;

        selectionBox.style.width = `${Math.abs(width)}px`;
        selectionBox.style.height = `${Math.abs(height)}px`;
        selectionBox.style.left = `${width < 0 ? currentPos.x : startPos.x}px`;
        selectionBox.style.top = `${height < 0 ? currentPos.y : startPos.y}px`;
    }

    function endSelection(e) {
        if (!isSelecting || !currentTapBlock) return;

        isSelecting = false;
        const rect = simulator.getBoundingClientRect();
        const bounds = selectionBox.getBoundingClientRect();

        const region = {
            x1: ((bounds.left - rect.left) / rect.width) * DEVICE_WIDTH,
            y1: ((bounds.top - rect.top) / rect.height) * DEVICE_HEIGHT,
            x2: ((bounds.right - rect.left) / rect.width) * DEVICE_WIDTH,
            y2: ((bounds.bottom - rect.top) / rect.height) * DEVICE_HEIGHT
        };

        // Find the block element that owns this tap block
        const blockEl = document.querySelector(`.tap-block.active-block`);
        if (blockEl) {
            const regionInfo = blockEl.querySelector('.region-info');
            if (regionInfo) {
                currentTapBlock.region = region;
                regionInfo.classList.remove('text-muted');
                regionInfo.textContent = `Region: (${Math.round(region.x1)}, ${Math.round(region.y1)}) - (${Math.round(region.x2)}, ${Math.round(region.y2)})`;
            }
        }

        selectionBox.classList.add('d-none');
        saveTasks();
    }
}

function disableDrawingMode() {
    const activeBlock = document.querySelector('.active-block');
    if (activeBlock) {
        activeBlock.classList.remove('active-block');
    }
    currentTapBlock = null;
    const simulator = document.getElementById('simulator');
    simulator.removeEventListener('mousedown', startSelection);
    simulator.removeEventListener('mousemove', updateSelection);
    simulator.removeEventListener('mouseup', endSelection);
}

function setBlockFocus(block, blockDiv) {
    // Remove focus from other blocks
    document.querySelectorAll('.block').forEach(b => b.classList.remove('focused'));

    // Set focus on current block
    blockDiv.classList.add('focused');
    window.state.focusedBlock = block;
}

// Event listeners for drawing mode
document.addEventListener('keydown', (e) => {
  if ((e.key === 'Enter' || e.key === ' ') && currentTapBlock) {
      disableDrawingMode();
  }
});

function addFunctionBlock(parent) {
    const functionBlock = {
        id: Date.now(),
        type: 'function',
        name: 'New Function',
        blocks: []
    };
    parent.blocks.push(functionBlock);

    const blockDiv = document.createElement('div');
    blockDiv.className = 'block function-block';
    blockDiv.innerHTML = `
        <div class="d-flex justify-content-between align-items-center mb-2">
            <h6 class="block-name" contenteditable="true">${functionBlock.name}</h6>
            <button class="btn-close btn-close-white delete-block" aria-label="Delete"></button>
        </div>
        <div class="nested-blocks"></div>
        <div class="d-flex gap-2 mt-2">
            <button class="btn btn-sm btn-outline-primary add-tap-btn">Add Tap</button>
            <button class="btn btn-sm btn-outline-success add-loop-btn">Add Loop</button>
        </div>
    `;

    blockDiv.querySelector('.btn-close').addEventListener('click', () => {
        const index = parent.blocks.indexOf(functionBlock);
        if (index > -1) {
            parent.blocks.splice(index, 1);
            blockDiv.remove();
            saveTasks();
        }
    });

    blockDiv.querySelector('.add-tap-btn').addEventListener('click', () => {
        const tapDiv = addTapBlock(functionBlock);
        blockDiv.querySelector('.nested-blocks').appendChild(tapDiv);
        saveTasks();
    });

    blockDiv.querySelector('.add-loop-btn').addEventListener('click', () => {
        const loopDiv = addLoopBlock(functionBlock);
        blockDiv.querySelector('.nested-blocks').appendChild(loopDiv);
        saveTasks();
    });

    return blockDiv;
}

window.addTapBlock = addTapBlock;
window.addLoopBlock = addLoopBlock;
window.addPrintBlock = addPrintBlock;
window.addFunctionBlock = addFunctionBlock;