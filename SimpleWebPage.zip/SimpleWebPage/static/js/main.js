// Combined JavaScript functionality from blocks.js and simulator.js

// Global state setup
window.state = {
    currentTask: null,
    tasks: [],
    autoSaveTimeout: null,
    pendingBlockConfiguration: null,
    focusedBlock: null,
    lastTaskId: null,
    currentFrame: null,
    functionOverlaysEnabled: true,
    executingBlocks: new Set(),
    functions: [],
    currentTapBlock: null
};

// Debug utility
const DEBUG = {
    LEVELS: {
        INFO: 'info',
        WARNING: 'warning',
        ERROR: 'error',
        SUCCESS: 'success',
        DEBUG: 'debug'
    },

    log(message, level = 'info', data = null) {
        const timestamp = new Date().toISOString();
        const logMessage = `[${timestamp}] ${level.toUpperCase()}: ${message}`;

        switch(level) {
            case 'error':
                console.error(logMessage, data || '');
                break;
            case 'warning':
                console.warn(logMessage, data || '');
                break;
            case 'success':
                console.log('%c' + logMessage, 'color: green', data || '');
                break;
            case 'debug':
                console.debug(logMessage, data || '');
                break;
            default:
                console.log(logMessage, data || '');
        }

        const consoleEl = document.getElementById('liveConsole');
        if (consoleEl) {
            const entry = document.createElement('div');
            entry.className = `console-entry ${level}`;
            entry.innerHTML = `
                <span class="timestamp">${timestamp}</span>
                <span class="message">${message}</span>
                ${data ? `<pre class="data">${JSON.stringify(data, null, 2)}</pre>` : ''}
            `;
            consoleEl.appendChild(entry);
            consoleEl.scrollTop = consoleEl.scrollHeight;
        }
    }
};

window.DEBUG = DEBUG;

// Device dimensions
const DEVICE_WIDTH = 320;
const DEVICE_HEIGHT = 720;

// Block Management Functions
function addTapBlock(parent) {
    window.taskManager.blockCounts.tap++;
    const tapBlock = {
        id: Date.now() + Math.random(), // Ensure unique ID
        type: 'tap',
        region: null,
        name: `Tap ${window.taskManager.blockCounts.tap}`
    };
    parent.blocks.push(tapBlock);

    // Create the DOM element
    const blockDiv = document.createElement('div');
    blockDiv.className = 'block tap-block';
    blockDiv.draggable = true;
    blockDiv.dataset.blockId = tapBlock.id;
    blockDiv.innerHTML = `
        <div class="d-flex justify-content-between align-items-center mb-2">
            <h6 class="block-name" contenteditable="true">${tapBlock.name}</h6>
            <button class="btn-close btn-close-white delete-block" aria-label="Delete"></button>
        </div>
        <div class="region-info text-muted">Click to set region</div>
    `;

    // Setup event listeners
    setupDragAndDrop(blockDiv);

    blockDiv.querySelector('.delete-block').addEventListener('click', () => {
        const blockIndex = parent.blocks.findIndex(b => b.id === tapBlock.id);
        if (blockIndex > -1) {
            parent.blocks.splice(blockIndex, 1);
            blockDiv.remove();
            window.taskManager.saveTasks();
        }
    });

    blockDiv.addEventListener('click', () => {
        setBlockFocus(tapBlock, blockDiv);
        enableDrawingMode(tapBlock, blockDiv);
    });

    return blockDiv;
}
function addLoopBlock(parent) {
    window.taskManager.blockCounts.loop++;
    const loopBlock = {
        id: Date.now(),
        type: 'loop',
        iterations: 1,
        blocks: [],
        name: `Loop ${window.taskManager.blockCounts.loop}`
    };
    parent.blocks.push(loopBlock);

    const blockDiv = document.createElement('div');
    blockDiv.className = 'block loop-block';
    blockDiv.draggable = true;
    blockDiv.dataset.blockId = loopBlock.id;
    blockDiv.innerHTML = `
        <div class="d-flex justify-content-between align-items-center mb-2">
            <h6 class="block-name" contenteditable="true">${loopBlock.name}</h6>
            <button class="btn-close btn-close-white delete-block" aria-label="Delete"></button>
        </div>
        <div class="input-group mb-2">
            <span class="input-group-text">Iterations</span>
            <input type="number" class="form-control iterations-input" value="1" min="1">
        </div>
        <div class="nested-blocks"></div>
        <div class="d-flex gap-2 mt-2">
            <button class="btn btn-sm btn-outline-primary add-tap-btn">Add Tap</button>
            <button class="btn btn-sm btn-outline-info add-print-btn">Add Print</button>
        </div>
    `;

    setupDragAndDrop(blockDiv);

    blockDiv.querySelector('.delete-block').addEventListener('click', () => {
        const blockIndex = window.state.currentTask.blocks.findIndex(b => b.id === loopBlock.id);
        if (blockIndex > -1) {
            window.state.currentTask.blocks.splice(blockIndex, 1);
            blockDiv.remove();
            DEBUG.log('Loop block removed', 'info');
            window.taskManager.saveTasks();
        }
    });

    blockDiv.querySelector('.iterations-input').addEventListener('change', (e) => {
        loopBlock.iterations = parseInt(e.target.value) || 1;
        window.taskManager.saveTasks();
    });

    blockDiv.querySelector('.add-tap-btn').addEventListener('click', () => {
        const tapDiv = addTapBlock(loopBlock);
        blockDiv.querySelector('.nested-blocks').appendChild(tapDiv);
        window.taskManager.saveTasks();
    });

    blockDiv.querySelector('.add-print-btn').addEventListener('click', () => {
        const printDiv = addPrintBlock(loopBlock);
        blockDiv.querySelector('.nested-blocks').appendChild(printDiv);
        window.taskManager.saveTasks();
    });

    return blockDiv;
}

function addPrintBlock(parent) {
    const printBlock = {
        id: Date.now(),
        type: 'print',
        message: '',
        name: 'Print Block'
    };
    parent.blocks.push(printBlock);

    const blockDiv = document.createElement('div');
    blockDiv.className = 'block print-block';
    blockDiv.draggable = true;
    blockDiv.dataset.blockId = printBlock.id;
    blockDiv.innerHTML = `
        <div class="d-flex justify-content-between align-items-center mb-2">
            <h6 class="block-name" contenteditable="true">${printBlock.name}</h6>
            <button class="btn-close btn-close-white delete-block" aria-label="Delete"></button>
        </div>
        <div class="input-group">
            <span class="input-group-text">Message</span>
            <input type="text" class="form-control message-input" value="${printBlock.message}" placeholder="Enter message">
        </div>
    `;

    setupDragAndDrop(blockDiv);

    blockDiv.querySelector('.message-input').addEventListener('input', (e) => {
        printBlock.message = e.target.value;
        window.taskManager.saveTasks();
    });

    blockDiv.querySelector('.delete-block').addEventListener('click', () => {
        const blockIndex = window.state.currentTask.blocks.findIndex(b => b.id === printBlock.id);
        if (blockIndex > -1) {
            window.state.currentTask.blocks.splice(blockIndex, 1);
            blockDiv.remove();
            DEBUG.log('Print block removed', 'info');
            window.taskManager.saveTasks();
        }
    });

    return blockDiv;
}

function setupDragAndDrop(element) {
    element.addEventListener('dragstart', (e) => {
        e.target.classList.add('dragging');
    });

    element.addEventListener('dragend', (e) => {
        e.target.classList.remove('dragging');
        window.taskManager.saveTasks();
    });

    element.addEventListener('dragover', (e) => {
        e.preventDefault();
        const container = e.target.closest('.nested-blocks');
        if (!container) return;

        const draggable = document.querySelector('.dragging');
        if (!draggable) return;

        const afterElement = getDragAfterElement(container, e.clientY);
        if (afterElement) {
            container.insertBefore(draggable, afterElement);
        } else {
            container.appendChild(draggable);
        }
    });
}

function getDragAfterElement(container, y) {
    const draggableElements = [...container.querySelectorAll('.block:not(.dragging)')];

    return draggableElements.reduce((closest, child) => {
        const box = child.getBoundingClientRect();
        const offset = y - box.top - box.height / 2;

        if (offset < 0 && offset > closest.offset) {
            return { offset: offset, element: child };
        } else {
            return closest;
        }
    }, { offset: Number.NEGATIVE_INFINITY }).element;
}

function setBlockFocus(block, blockDiv) {
    document.querySelectorAll('.block').forEach(b => b.classList.remove('focused'));
    blockDiv.classList.add('focused');
    window.state.focusedBlock = block;

    // Hide any existing selection box first
    const selectionBox = document.getElementById('selectionBox');
    selectionBox.classList.add('d-none');

    // Show region visualization if it's a tap block with a region
    if (block.type === 'tap' && block.region) {
        const simulator = document.getElementById('simulator');
        const simulatorBounds = simulator.getBoundingClientRect();

        // Calculate scaled coordinates
        const scaledX1 = (block.region.x1 / DEVICE_WIDTH) * simulatorBounds.width;
        const scaledY1 = (block.region.y1 / DEVICE_HEIGHT) * simulatorBounds.height;
        const scaledX2 = (block.region.x2 / DEVICE_WIDTH) * simulatorBounds.width;
        const scaledY2 = (block.region.y2 / DEVICE_HEIGHT) * simulatorBounds.height;

        // Update selection box position and size
        selectionBox.classList.remove('d-none');
        selectionBox.style.left = `${Math.min(scaledX1, scaledX2)}px`;
        selectionBox.style.top = `${Math.min(scaledY1, scaledY2)}px`;
        selectionBox.style.width = `${Math.abs(scaledX2 - scaledX1)}px`;
        selectionBox.style.height = `${Math.abs(scaledY2 - scaledY1)}px`;

        DEBUG.log('Showing region for tap block', 'info', {
            blockId: block.id,
            region: block.region,
            scaled: {
                x1: scaledX1,
                y1: scaledY1,
                x2: scaledX2,
                y2: scaledY2
            }
        });
    }
}

function enableDrawingMode(tapBlock, tapDiv) {
    window.state.currentTapBlock = tapBlock;

    document.querySelectorAll('.active-block').forEach(block => {
        if (block !== tapDiv) {
            block.classList.remove('active-block');
        }
    });

    tapDiv.classList.add('active-block');
    const simulator = document.getElementById('simulator');
    const selectionBox = document.getElementById('selectionBox');

    // Show existing region if it exists
    if (tapBlock.region) {
        const simulatorBounds = simulator.getBoundingClientRect();
        const scaledX1 = (tapBlock.region.x1 / DEVICE_WIDTH) * simulatorBounds.width;
        const scaledY1 = (tapBlock.region.y1 / DEVICE_HEIGHT) * simulatorBounds.height;
        const scaledX2 = (tapBlock.region.x2 / DEVICE_WIDTH) * simulatorBounds.width;
        const scaledY2 = (tapBlock.region.y2 / DEVICE_HEIGHT) * simulatorBounds.height;

        selectionBox.classList.remove('d-none');
        selectionBox.style.left = `${Math.min(scaledX1, scaledX2)}px`;
        selectionBox.style.top = `${Math.min(scaledY1, scaledY2)}px`;
        selectionBox.style.width = `${Math.abs(scaledX2 - scaledX1)}px`;
        selectionBox.style.height = `${Math.abs(scaledY2 - scaledY1)}px`;
    } else {
        selectionBox.classList.add('d-none');
    }

    let isSelecting = false;
    let startPos = { x: 0, y: 0 };

    // Remove existing event listeners
    simulator.removeEventListener('mousedown', startSelection);
    simulator.removeEventListener('mousemove', updateSelection);
    simulator.removeEventListener('mouseup', endSelection);

    // Add new event listeners
    simulator.addEventListener('mousedown', startSelection);
    simulator.addEventListener('mousemove', updateSelection);
    simulator.addEventListener('mouseup', endSelection);

    function startSelection(e) {
        if (!window.state.currentTapBlock || e.target.closest('.block')) return;

        const rect = simulator.getBoundingClientRect();
        startPos = {
            x: e.clientX - rect.left,
            y: e.clientY - rect.top
        };

        selectionBox.classList.remove('d-none');
        selectionBox.style.left = `${startPos.x}px`;
        selectionBox.style.top = `${startPos.y}px`;
        selectionBox.style.width = '0px';
        selectionBox.style.height = '0px';

        isSelecting = true;
    }

    function updateSelection(e) {
        if (!isSelecting) return;

        const rect = simulator.getBoundingClientRect();
        const currentPos = {
            x: e.clientX - rect.left,
            y: e.clientY - rect.top
        };

        const width = currentPos.x - startPos.x;
        const height = currentPos.y - startPos.y;

        selectionBox.style.width = `${Math.abs(width)}px`;
        selectionBox.style.height = `${Math.abs(height)}px`;
        selectionBox.style.left = `${width < 0 ? currentPos.x : startPos.x}px`;
        selectionBox.style.top = `${height < 0 ? currentPos.y : startPos.y}px`;
    }

    function endSelection() {
        if (!isSelecting || !window.state.currentTapBlock) return;

        isSelecting = false;
        const rect = simulator.getBoundingClientRect();
        const bounds = selectionBox.getBoundingClientRect();

        const region = {
            x1: ((bounds.left - rect.left) / rect.width) * DEVICE_WIDTH,
            y1: ((bounds.top - rect.top) / rect.height) * DEVICE_HEIGHT,
            x2: ((bounds.right - rect.left) / rect.width) * DEVICE_WIDTH,
            y2: ((bounds.bottom - rect.top) / rect.height) * DEVICE_HEIGHT
        };

        window.state.currentTapBlock.region = region;
        const activeBlock = document.querySelector('.active-block');
        if (activeBlock) {
            const regionInfo = activeBlock.querySelector('.region-info');
            if (regionInfo) {
                regionInfo.classList.remove('text-muted');
                regionInfo.textContent = `Region: (${Math.round(region.x1)}, ${Math.round(region.y1)}) - (${Math.round(region.x2)}, ${Math.round(region.y2)})`;
            }
        }

        window.taskManager.saveTasks();
    }
}

function disableDrawingMode() {
    const activeBlock = document.querySelector('.active-block');
    if (activeBlock) {
        activeBlock.classList.remove('active-block');
    }
    window.state.currentTapBlock = null;
    window.state.focusedBlock = null;
    const simulator = document.getElementById('simulator');
    const selectionBox = document.getElementById('selectionBox');
    selectionBox.classList.add('d-none');
}

document.addEventListener('keydown', (e) => {
    if ((e.key === 'Enter' || e.key === ' ') && window.state.focusedBlock) {
        disableDrawingMode();
    }
});

// Simulator Class
class Simulator {
    constructor() {
        DEBUG.log('Initializing Simulator', 'info');
        this.isExecuting = false;
    }

    async executeTask(task) {
        if (!task || !task.blocks) {
            DEBUG.log('No task or blocks to execute', 'error');
            return;
        }

        if (this.isExecuting) {
            DEBUG.log('Task already executing', 'warning');
            return;
        }

        const executeBtn = document.getElementById('executeTaskBtn');
        if (executeBtn) {
            executeBtn.disabled = true;
            executeBtn.textContent = 'Executing...';
        }

        this.isExecuting = true;
        DEBUG.log('Starting task execution', 'info', { taskName: task.name });

        try {
            // Clear any focused blocks
            document.querySelectorAll('.block').forEach(b => 
                b.classList.remove('focused', 'executing'));

            if (task.blocks && task.blocks.length > 0) {
                // Get flattened queue of blocks including loop iterations
                const queue = this.flattenBlocks(task.blocks);
                DEBUG.log('Execution queue prepared', 'info', { blockCount: queue.length });

                // Execute each block in the queue
                for (const block of queue) {
                    if (!this.isExecuting) {
                        DEBUG.log('Execution cancelled', 'warning');
                        break;
                    }
                    await this.executeBlock(block);
                }
            }
        } catch (error) {
            DEBUG.log('Task execution error', 'error', error);
        } finally {
            this.isExecuting = false;
            if (executeBtn) {
                executeBtn.disabled = false;
                executeBtn.textContent = 'Execute';
            }
            DEBUG.log('Task execution completed', 'success');
        }
    }

    flattenBlocks(blocks, iterations = 1) {
        let queue = [];
        for (const block of blocks) {
            if (block.type === 'loop') {
                // Get the total number of iterations for this loop
                const loopIterations = parseInt(block.iterations) || 1;

                // For each iteration of this loop
                for (let i = 0; i < loopIterations; i++) {
                    // If the loop has nested blocks, flatten them
                    if (block.blocks && Array.isArray(block.blocks)) {
                        queue = queue.concat(this.flattenBlocks(block.blocks));
                    }
                }
            } else {
                // For non-loop blocks, just add them to the queue
                queue.push(block);
            }
        }
        return queue;
    }

    async executeBlock(block) {
        if (!this.isExecuting) return;

        try {
            const blockElement = document.querySelector(`.block[data-block-id="${block.id}"]`);
            if (blockElement) {
                blockElement.classList.add('executing');
            }

            switch (block.type) {
                case 'tap':
                    if (block.region) {
                        const x = Math.random() * (block.region.x2 - block.region.x1) + block.region.x1;
                        const y = Math.random() * (block.region.y2 - block.region.y1) + block.region.y1;

                        DEBUG.log('Executing tap with region:', 'info', {
                            region: block.region,
                            calculatedCoordinates: { x, y }
                        });

                        await this.executeTap(x, y);
                        // Add delay after tap
                        await new Promise(resolve => setTimeout(resolve, 800));
                    } else {
                        DEBUG.log('No region defined for tap block', 'warning', block);
                    }
                    break;

                case 'loop':
                    const iterations = parseInt(block.iterations) || 1;
                    for (let i = 0; i < iterations && this.isExecuting; i++) {
                        DEBUG.log(`Loop iteration ${i + 1}/${iterations}`, 'info');
                        if (block.blocks && Array.isArray(block.blocks)) {
                            for (const childBlock of block.blocks) {
                                await this.executeBlock(childBlock);
                            }
                        }
                    }
                    break;

                case 'print':
                    DEBUG.log(block.message || 'Empty print message', 'info');
                    await new Promise(resolve => setTimeout(resolve, 500));
                    break;
            }
        } catch (error) {
            DEBUG.log('Block execution error', 'error', error);
        } finally {
            const blockElement = document.querySelector(`.block[data-block-id="${block.id}"]`);
            if (blockElement) {
                blockElement.classList.remove('executing');
            }
        }
    }

    async executeTap(x, y) {
        return new Promise((resolve) => {
            const simulator = document.getElementById('simulator');
            const simulatorBounds = simulator.getBoundingClientRect();
            const scaledX = (x / DEVICE_WIDTH) * simulatorBounds.width;
            const scaledY = (y / DEVICE_HEIGHT) * simulatorBounds.height;

            // Create and show tap feedback
            const feedback = document.createElement('div');
            feedback.className = 'tap-feedback';
            feedback.style.left = `${scaledX}px`;
            feedback.style.top = `${scaledY}px`;
            simulator.appendChild(feedback);

            // Generate G-code command (currently unused)
            const gcode = `G1 X${Math.round(x)} Y${Math.round(y)} F1000; TAP`;
            DEBUG.log('Tap executed', 'info', { x, y, gcode });

            // Wait for animation to complete
            setTimeout(() => {
                feedback.remove();
                resolve();
            }, 800);
        });
    }
}
// Task Management Class
class TaskManager {
    constructor() {
        this.tasks = [];
        this.currentTask = null;
        this.blockCounts = { tap: 0, loop: 0 }; // Initialize block counters
        this.setupEventListeners();
        this.loadSavedTasks();
    }

    setupEventListeners() {
        document.getElementById('addTapBtn').addEventListener('click', () => {
            if (!window.state.currentTask) {
                const task = this.createNewTask();
                this.loadTask(task);
                const firstTaskEl = document.querySelector('.task-list-item');
                if (firstTaskEl) {
                    firstTaskEl.classList.add('active');
                }
                window.state.currentTask = task;
            }

            if (window.state.currentTask) {
                const nestedBlocks = document.querySelector('#currentTask .nested-blocks');
                const tapDiv = addTapBlock(window.state.currentTask);

                if (nestedBlocks && tapDiv) {
                    nestedBlocks.appendChild(tapDiv);
                    this.saveTasks();
                    setBlockFocus(window.state.currentTask.blocks[window.state.currentTask.blocks.length - 1], tapDiv);
                    enableDrawingMode(window.state.currentTask.blocks[window.state.currentTask.blocks.length - 1], tapDiv);
                    DEBUG.log('Added new tap block', 'success', { task: window.state.currentTask.name });
                }
            } else {
                DEBUG.log('No task selected', 'warning');
            }
        });

        document.getElementById('addLoopBtn').addEventListener('click', () => {
            if (window.state.currentTask) {
                const loopDiv = addLoopBlock(window.state.currentTask);
                const nestedBlocks = document.querySelector('#currentTask .nested-blocks');
                if (nestedBlocks) {
                    nestedBlocks.appendChild(loopDiv);
                    this.saveTasks();
                }
            }
        });

        // In your initialization code
        document.getElementById('executeTaskBtn').addEventListener('click', () => {
            if (!window.state.currentTask) {
                DEBUG.log('No task selected', 'warning');
                return;
            }

            if (window.simulator.isExecuting) {
                DEBUG.log('Task already executing', 'warning');
                return;
            }

            window.simulator.executeTask(window.state.currentTask);
        });
        document.getElementById('newTaskBtn').addEventListener('click', () => {
            const task = this.createNewTask();
            this.renderTask(task);
            this.saveTasks();
        });

        document.getElementById('deleteAllTasksBtn').addEventListener('click', () => {
            this.deleteAllTasks();
        });
    }

    createNewTask() {
        const task = {
            id: Date.now(),
            name: 'New Task',
            blocks: [],
            created: new Date().toISOString()
        };

        window.state.tasks.push(task);
        window.state.currentTask = task;

        const currentTaskEl = document.getElementById('currentTask');
        if (currentTaskEl) {
            currentTaskEl.innerHTML = '<div class="nested-blocks"></div>';
        }

        const taskTitle = document.getElementById('taskTitle');
        if (taskTitle) {
            taskTitle.value = task.name;
        }

        DEBUG.log('New task created', 'success', task);
        return task;
    }

    renderTask(task) {
        const taskListEl = document.getElementById('taskList');
        if (!taskListEl) return;

        const taskEl = document.createElement('div');
        taskEl.className = 'task-list-item';
        taskEl.dataset.taskId = task.id;
        taskEl.innerHTML = `
            <span>${task.name}</span>
            <button class="btn btn-sm btn-outline-danger delete-btn">Delete</button>
        `;

        taskEl.addEventListener('click', (e) => {
            if (!e.target.classList.contains('delete-btn')) {
                this.loadTask(task);
                document.querySelectorAll('.task-list-item').forEach(el => {
                    el.classList.remove('active');
                });
                taskEl.classList.add('active');
            }
        });

        taskEl.querySelector('.delete-btn').addEventListener('click', () => {
            const index = window.state.tasks.indexOf(task);
            if (index > -1) {
                window.state.tasks.splice(index, 1);
                taskEl.remove();
                if (window.state.currentTask === task) {
                    window.state.currentTask = null;
                    const currentTask = document.getElementById('currentTask');
                    if (currentTask) {
                        currentTask.innerHTML = '';
                    }
                }
                this.saveTasks();
            }
        });

        taskListEl.appendChild(taskEl);
    }

    loadTask(task) {
        window.state.currentTask = task;

        const currentTaskEl = document.getElementById('currentTask');
        if (currentTaskEl) {
            // Clear only the display
            currentTaskEl.innerHTML = '<div class="nested-blocks"></div>';

            // Recursively render all blocks
            const renderBlocks = (blocks, parentEl) => {
                blocks.forEach(block => {
                    let blockDiv;

                    switch (block.type) {
                            case 'tap':
                            blockDiv = document.createElement('div');
                            blockDiv.className = 'block tap-block';
                            blockDiv.draggable = true;
                            blockDiv.dataset.blockId = block.id;
                            blockDiv.innerHTML = `
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <h6 class="block-name" contenteditable="true">${block.name}</h6>
                                    <button class="btn-close btn-close-white delete-block" aria-label="Delete"></button>
                                </div>
                                <div class="region-info ${block.region ? '' : 'text-muted'}">
                                    ${block.region ? 
                                        `Region: (${Math.round(block.region.x1)}, ${Math.round(block.region.y1)}) - (${Math.round(block.region.x2)}, ${Math.round(block.region.y2)})` : 
                                        'Click to set region'}
                                </div>
                            `;
                            setupDragAndDrop(blockDiv);

                            // Add click handler for tap functionality
                            blockDiv.addEventListener('click', (e) => {
                                if (!e.target.classList.contains('delete-block')) {
                                    setBlockFocus(block, blockDiv);
                                    enableDrawingMode(block, blockDiv);
                                }
                            });

                            // Add delete handler
                            blockDiv.querySelector('.delete-block').addEventListener('click', (e) => {
                                e.stopPropagation(); // Prevent the tap click handler from firing
                                const parentBlocks = parentEl === currentTaskEl.querySelector('.nested-blocks') ? 
                                    task.blocks : 
                                    block.parent.blocks;
                                const index = parentBlocks.findIndex(b => b.id === block.id);
                                if (index > -1) {
                                    parentBlocks.splice(index, 1);
                                    blockDiv.remove();
                                    this.saveTasks();
                                    DEBUG.log('Tap block deleted', 'info', { blockId: block.id });
                                }
                            });
                            break;
                            case 'loop':
                            blockDiv = document.createElement('div');
                            blockDiv.className = 'block loop-block';
                            blockDiv.draggable = true;
                            blockDiv.dataset.blockId = block.id;
                            blockDiv.innerHTML = `
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <h6 class="block-name" contenteditable="true">${block.name}</h6>
                                    <button class="btn-close btn-close-white delete-block" aria-label="Delete"></button>
                                </div>
                                <div class="input-group mb-2">
                                    <span class="input-group-text">Iterations</span>
                                    <input type="number" class="form-control iterations-input" value="${block.iterations || 1}" min="1">
                                </div>
                                <div class="nested-blocks"></div>
                                <div class="d-flex gap-2 mt-2">
                                    <button class="btn btn-sm btn-outline-primary add-tap-btn">Add Tap</button>
                                    <button class="btn btn-sm btn-outline-info add-print-btn">Add Print</button>
                                </div>
                            `;
                            setupDragAndDrop(blockDiv);

                            // Setup loop block event listeners
                            blockDiv.querySelector('.iterations-input').addEventListener('change', (e) => {
                                block.iterations = parseInt(e.target.value) || 1;
                                this.saveTasks();
                            });

                            blockDiv.querySelector('.add-tap-btn').addEventListener('click', () => {
                                const tapDiv = addTapBlock(block);
                                blockDiv.querySelector('.nested-blocks').appendChild(tapDiv);
                                this.saveTasks();
                            });

                            blockDiv.querySelector('.add-print-btn').addEventListener('click', () => {
                                const printDiv = addPrintBlock(block);
                                blockDiv.querySelector('.nested-blocks').appendChild(printDiv);
                                this.saveTasks();
                            });

                            // Add delete handler for loop block
                            blockDiv.querySelector('.delete-block').addEventListener('click', (e) => {
                                e.stopPropagation();
                                const parentBlocks = parentEl === currentTaskEl.querySelector('.nested-blocks') ? 
                                    task.blocks : 
                                    block.parent.blocks;
                                const index = parentBlocks.findIndex(b => b.id === block.id);
                                if (index > -1) {
                                    parentBlocks.splice(index, 1);
                                    blockDiv.remove();
                                    this.saveTasks();
                                    DEBUG.log('Loop block deleted', 'info', { blockId: block.id });
                                }
                            });
                            break;
                        case 'print':
                            blockDiv = document.createElement('div');
                            blockDiv.className = 'block print-block';
                            blockDiv.draggable = true;
                            blockDiv.dataset.blockId = block.id;
                            blockDiv.innerHTML = `
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <h6 class="block-name" contenteditable="true">${block.name}</h6>
                                    <button class="btn-close btn-close-white delete-block" aria-label="Delete"></button>
                                </div>
                                <div class="input-group">
                                    <span class="input-group-text">Message</span>
                                    <input type="text" class="form-control message-input" value="${block.message || ''}" placeholder="Enter message">
                                </div>
                            `;
                            setupDragAndDrop(blockDiv);

                            blockDiv.querySelector('.message-input').addEventListener('input', (e) => {
                                block.message = e.target.value;
                                this.saveTasks();
                            });
                            break;
                    }

                    if (blockDiv) {
                        // Add delete functionality
                        blockDiv.querySelector('.delete-block').addEventListener('click', () => {
                            const parentBlocks = parentEl === currentTaskEl.querySelector('.nested-blocks') ? 
                                task.blocks : 
                                block.parent.blocks;
                            const index = parentBlocks.indexOf(block);
                            if (index > -1) {
                                parentBlocks.splice(index, 1);
                                blockDiv.remove();
                                this.saveTasks();
                            }
                        });

                        parentEl.appendChild(blockDiv);

                        // Render nested blocks for loop blocks
                        if (block.type === 'loop' && block.blocks) {
                            const nestedContainer = blockDiv.querySelector('.nested-blocks');
                            if (nestedContainer) {
                                renderBlocks(block.blocks, nestedContainer);
                            }
                        }
                    }
                });
            };

            // Render the blocks from the task data
            renderBlocks(task.blocks, currentTaskEl.querySelector('.nested-blocks'));
        }

        const taskTitle = document.getElementById('taskTitle');
        if (taskTitle) {
            taskTitle.value = task.name;
            if (!taskTitle._updateTaskName) {
                taskTitle._updateTaskName = () => {
                    task.name = taskTitle.value;
                    const taskEl = document.querySelector(`.task-list-item[data-task-id="${task.id}"]`);
                    if (taskEl) {
                        taskEl.querySelector('span').textContent = task.name;
                    }
                    this.saveTasks();
                };
                taskTitle.addEventListener('input', taskTitle._updateTaskName);
            }
        }

        this.refreshBlockData();
        DEBUG.log('Task loaded successfully', 'success', { taskId: task.id });
    }
    refreshBlockData() {
        if (!window.state.currentTask) return;

        const currentTaskEl = document.getElementById('currentTask');
        if (!currentTaskEl) return;

        currentTaskEl.querySelectorAll('.block').forEach(blockDiv => {
            const blockId = blockDiv.dataset.blockId;
            const block = this.findBlockById(window.state.currentTask.blocks, blockId);

            if (block) {
                if (block.type === 'loop') {
                    const iterationsInput = blockDiv.querySelector('.iterations-input');
                    if (iterationsInput) {
                        iterationsInput.value = block.iterations;
                    }
                }
                if (block.type === 'tap' && block.region) {
                    const regionInfo = blockDiv.querySelector('.region-info');
                    if (regionInfo) {
                        regionInfo.classList.remove('text-muted');
                        regionInfo.textContent = `Region: (${Math.round(block.region.x1)}, ${Math.round(block.region.y1)}) - (${Math.round(block.region.x2)}, ${Math.round(block.region.y2)})`;
                    }
                }
            }
        });
    }

    findBlockById(blocks, id) {
        for (const block of blocks) {
            if (block.id.toString() === id) return block;
            if (block.blocks) {
                const found = this.findBlockById(block.blocks, id);
                if (found) return found;
            }
        }
        return null;
    }


    loadSavedTasks() {
        const savedTasks = localStorage.getItem('tasks');
        if (savedTasks) {
            window.state.tasks = JSON.parse(savedTasks);
            window.state.tasks.forEach(task => {
                this.renderTask(task);
                if (task.blocks) {
                    task.blocks.forEach(block => {
                        if (block.type === 'tap' && block.region) {
                            const blockEl = document.querySelector(`.block[data-block-id="${block.id}"]`);
                            if (blockEl) {
                                const regionInfo = blockEl.querySelector('.region-info');
                                if (regionInfo) {
                                    regionInfo.classList.remove('text-muted');
                                    regionInfo.textContent = `Region: (${Math.round(block.region.x1)}, ${Math.round(block.region.y1)}) - (${Math.round(block.region.x2)}, ${Math.round(block.region.y2)})`;
                                }
                            }
                        }
                    });
                }
            });
            DEBUG.log('Tasks loaded from storage', 'success');
        }
    }

    saveTasks() {
        const currentTask = document.getElementById('currentTask');
        if (currentTask && window.state.currentTask) {
            const blocks = [];
            const usedIds = new Set(); // Track used IDs

            const processBlocks = (container, parentArray) => {
                container.querySelectorAll(':scope > .block').forEach(blockDiv => {
                    const blockId = blockDiv.dataset.blockId;
                    let block = null;
                    // First try to find in current task blocks
                    const findBlock = (blockArray, id) => {
                        for (const b of blockArray) {
                            if (b.id.toString() === id) return b;
                            if (b.blocks) {
                                const found = findBlock(b.blocks, id);
                                if (found) return found;
                            }
                        }
                        return null;
                    };

                    block = findBlock(window.state.currentTask.blocks, blockId);

                    if (block) {
                        // Ensure unique ID
                        if (usedIds.has(block.id)) {
                            block.id = Date.now() + Math.random();
                            blockDiv.dataset.blockId = block.id;
                        }
                        usedIds.add(block.id);

                        const blockCopy = { ...block };
                        if (block.type === 'loop') {
                            blockCopy.blocks = [];
                            const nestedContainer = blockDiv.querySelector('.nested-blocks');
                            if (nestedContainer) {
                                processBlocks(nestedContainer, blockCopy.blocks);
                            }
                        }
                        parentArray.push(blockCopy);
                    }
                });
            };

            const nestedBlocks = currentTask.querySelector('.nested-blocks');
            if (nestedBlocks) {
                processBlocks(nestedBlocks, blocks);
            }

            window.state.currentTask.blocks = blocks;

            // Update the task in the tasks array
            const taskIndex = window.state.tasks.findIndex(t => t.id === window.state.currentTask.id);
            if (taskIndex !== -1) {
                window.state.tasks[taskIndex] = window.state.currentTask;
            }
        }

        localStorage.setItem('tasks', JSON.stringify(window.state.tasks));
        DEBUG.log('Tasks saved successfully', 'success');
    }
    deleteAllTasks() {
        if (confirm('Are you sure you want to delete all tasks?')) {
            window.state.tasks = [];
            window.state.currentTask = null;
            document.getElementById('taskList').innerHTML = '';
            document.getElementById('currentTask').innerHTML = '';
            document.getElementById('taskTitle').value = '';
            this.saveTasks();
            DEBUG.log('All tasks deleted', 'warning');
        }
    }
}

// Initialize everything when the document loads
document.addEventListener('DOMContentLoaded', () => {
    window.simulator = new Simulator();
    window.taskManager = new TaskManager();
    DEBUG.log('Application initialized', 'success');
});

// Make functions globally available
window.addTapBlock = addTapBlock;
window.addLoopBlock = addLoopBlock;
window.addPrintBlock = addPrintBlock;